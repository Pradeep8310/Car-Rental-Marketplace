import jwt from 'jsonwebtoken';
import User from '../models/User.js';

// Check if user is logged in
export const isLoggedIn = async (req, res, next) => {
  try {
    const token = req.cookies.token;
    
    if (!token) {
      req.flash('error_msg', 'Please log in to access this page');
      return res.redirect('/auth/login');
    }
    
    // Verify token
    const decoded = jwt.verify(token, 'your-jwt-secret');
    
    // Get user
    const user = await User.findById(decoded.id);
    
    if (!user) {
      res.clearCookie('token');
      req.flash('error_msg', 'User not found');
      return res.redirect('/auth/login');
    }
    
    // Add user to request
    req.user = user;
    res.locals.user = user;
    
    next();
  } catch (error) {
    console.error('Auth middleware error:', error);
    res.clearCookie('token');
    req.flash('error_msg', 'Invalid session, please log in again');
    res.redirect('/auth/login');
  }
};

// Check if user is owner
export const isOwner = (req, res, next) => {
  if (req.user && req.user.role === 'owner') {
    return next();
  }
  
  req.flash('error_msg', 'Access denied, owners only');
  res.redirect('/');
};

// Check if user is customer
export const isCustomer = (req, res, next) => {
  if (req.user && req.user.role === 'customer') {
    return next();
  }
  
  req.flash('error_msg', 'Access denied, customers only');
  res.redirect('/');
};

// Check current user (for every request)
export const checkUser = async (req, res, next) => {
  res.locals.user = null;
  
  const token = req.cookies.token;
  
  if (token) {
    try {
      // Verify token
      const decoded = jwt.verify(token, 'your-jwt-secret');
      
      // Get user
      const user = await User.findById(decoded.id);
      
      if (user) {
        res.locals.user = user;
      }
    } catch (error) {
      console.error('Check user error:', error);
      res.clearCookie('token');
    }
  }
  
  next();
};