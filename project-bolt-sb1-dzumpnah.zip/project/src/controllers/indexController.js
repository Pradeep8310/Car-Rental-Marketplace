import Car from '../models/Car.js';
import Category from '../models/Category.js';

// Home page
export const getHomePage = async (req, res) => {
  try {
    // Get featured cars (newest and best rated)
    const featuredCars = await Car.find({ isAvailable: true })
      .populate('category')
      .populate({
        path: 'reviews',
        model: 'Review'
      })
      .sort({ createdAt: -1 })
      .limit(6);
    
    // Get categories
    const categories = await Category.find();
    
    // Get popular locations
    const locations = await Car.aggregate([
      { $group: { _id: '$location', count: { $sum: 1 } } },
      { $sort: { count: -1 } },
      { $limit: 5 }
    ]);
    
    // Get count by category
    const categoryCounts = await Car.aggregate([
      { $group: { _id: '$category', count: { $sum: 1 } } }
    ]);
    
    // Map category IDs to names and counts
    const categoryData = await Promise.all(
      categoryCounts.map(async (item) => {
        const category = await Category.findById(item._id);
        return {
          name: category ? category.name : 'Unknown',
          count: item.count
        };
      })
    );
    
    res.render('index', {
      title: 'Car Rental Marketplace',
      featuredCars,
      categories,
      locations: locations.map(l => l._id),
      categoryData
    });
  } catch (error) {
    console.error('Home page error:', error);
    // Improved error handling with more specific error message
    res.status(500).render('error', {
      title: 'Service Temporarily Unavailable',
      message: 'We are experiencing technical difficulties. Please try again in a few moments.'
    });
  }
};

// About page
export const getAboutPage = (req, res) => {
  res.render('about', { title: 'About Us' });
};

// Contact page
export const getContactPage = (req, res) => {
  res.render('contact', { title: 'Contact Us' });
};

// Error page
export const getErrorPage = (req, res) => {
  res.render('404', { title: 'Page Not Found' });
};