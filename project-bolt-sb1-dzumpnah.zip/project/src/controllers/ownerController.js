import Car from '../models/Car.js';
import Booking from '../models/Booking.js';
import User from '../models/User.js';

// Get owner dashboard
export const getDashboard = async (req, res) => {
  try {
    // Get total number of cars
    const totalCars = await Car.countDocuments({ owner: req.user.id });
    
    // Get cars owned by user
    const cars = await Car.find({ owner: req.user.id })
      .populate('category')
      .sort({ createdAt: -1 })
      .limit(5);
    
    // Get car IDs
    const carIds = cars.map(car => car._id);
    
    // Get total bookings
    const totalBookings = await Booking.countDocuments({ 
      car: { $in: carIds }
    });
    
    // Get recent bookings
    const recentBookings = await Booking.find({ car: { $in: carIds } })
      .populate({
        path: 'car',
        select: 'title image'
      })
      .populate('user', 'name')
      .sort({ createdAt: -1 })
      .limit(5);
    
    // Calculate total earnings
    const earnings = await Booking.aggregate([
      { 
        $match: { 
          car: { $in: carIds },
          status: { $in: ['confirmed', 'completed'] }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$totalPrice' }
        }
      }
    ]);
    
    const totalEarnings = earnings.length > 0 ? earnings[0].total : 0;
    
    res.render('owner/dashboard', {
      title: 'Owner Dashboard',
      totalCars,
      totalBookings,
      totalEarnings,
      cars,
      recentBookings
    });
  } catch (error) {
    console.error('Owner dashboard error:', error);
    req.flash('error_msg', 'Failed to load dashboard');
    res.redirect('/');
  }
};

// Get owner cars
export const getCars = async (req, res) => {
  try {
    const cars = await Car.find({ owner: req.user.id })
      .populate('category')
      .sort({ createdAt: -1 });
    
    res.render('owner/cars', {
      title: 'My Cars',
      cars
    });
  } catch (error) {
    console.error('Get owner cars error:', error);
    req.flash('error_msg', 'Failed to load cars');
    res.redirect('/owner/dashboard');
  }
};

// Get owner profile
export const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    
    res.render('owner/profile', {
      title: 'My Profile',
      user
    });
  } catch (error) {
    console.error('Get owner profile error:', error);
    req.flash('error_msg', 'Failed to load profile');
    res.redirect('/owner/dashboard');
  }
};

// Update owner profile
export const updateProfile = async (req, res) => {
  try {
    const { name, phone, address } = req.body;
    
    await User.findByIdAndUpdate(req.user.id, {
      name,
      phone,
      address
    });
    
    req.flash('success_msg', 'Profile updated successfully');
    res.redirect('/owner/profile');
  } catch (error) {
    console.error('Update owner profile error:', error);
    req.flash('error_msg', 'Failed to update profile');
    res.redirect('/owner/profile');
  }
};

// Get earnings report
export const getEarningsReport = async (req, res) => {
  try {
    // Get all cars owned by this user
    const cars = await Car.find({ owner: req.user.id });
    const carIds = cars.map(car => car._id);
    
    // Get bookings grouped by month
    const bookings = await Booking.aggregate([
      {
        $match: {
          car: { $in: carIds },
          status: { $in: ['confirmed', 'completed'] }
        }
      },
      {
        $group: {
          _id: {
            month: { $month: '$createdAt' },
            year: { $year: '$createdAt' }
          },
          total: { $sum: '$totalPrice' },
          count: { $sum: 1 }
        }
      },
      {
        $sort: {
          '_id.year': -1,
          '_id.month': -1
        }
      }
    ]);
    
    // Transform results for easier rendering
    const monthNames = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];
    
    const earnings = bookings.map(booking => ({
      month: monthNames[booking._id.month - 1],
      year: booking._id.year,
      total: booking.total,
      count: booking.count
    }));
    
    // Calculate total overall
    const totalEarnings = earnings.reduce((sum, item) => sum + item.total, 0);
    const totalBookings = earnings.reduce((sum, item) => sum + item.count, 0);
    
    res.render('owner/earnings', {
      title: 'Earnings Report',
      earnings,
      totalEarnings,
      totalBookings
    });
  } catch (error) {
    console.error('Get earnings report error:', error);
    req.flash('error_msg', 'Failed to load earnings report');
    res.redirect('/owner/dashboard');
  }
};