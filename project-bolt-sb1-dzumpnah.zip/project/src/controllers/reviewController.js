import Review from '../models/Review.js';
import Booking from '../models/Booking.js';
import Car from '../models/Car.js';

// Create review
export const createReview = async (req, res) => {
  try {
    const { carId, rating, comment } = req.body;
    
    // Check if car exists
    const car = await Car.findById(carId);
    if (!car) {
      req.flash('error_msg', 'Car not found');
      return res.redirect('/cars');
    }
    
    // Check if user has booked this car
    const hasBooked = await Booking.findOne({
      car: carId,
      user: req.user.id,
      status: 'completed'
    });
    
    if (!hasBooked) {
      req.flash('error_msg', 'You can only review cars you have rented');
      return res.redirect(`/cars/${carId}`);
    }
    
    // Check if user already reviewed this car
    const existingReview = await Review.findOne({
      car: carId,
      user: req.user.id
    });
    
    if (existingReview) {
      // Update existing review
      existingReview.rating = rating;
      existingReview.comment = comment;
      await existingReview.save();
      
      req.flash('success_msg', 'Review updated successfully');
    } else {
      // Create new review
      await Review.create({
        car: carId,
        user: req.user.id,
        rating,
        comment
      });
      
      req.flash('success_msg', 'Review submitted successfully');
    }
    
    res.redirect(`/cars/${carId}`);
  } catch (error) {
    console.error('Create review error:', error);
    req.flash('error_msg', 'Failed to submit review');
    res.redirect(`/cars/${req.body.carId}`);
  }
};

// Delete review
export const deleteReview = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    
    if (!review) {
      req.flash('error_msg', 'Review not found');
      return res.redirect('/customer/dashboard');
    }
    
    // Check if user owns this review
    if (review.user.toString() !== req.user.id) {
      req.flash('error_msg', 'Not authorized to delete this review');
      return res.redirect(`/cars/${review.car}`);
    }
    
    // Delete review
    await Review.findByIdAndDelete(req.params.id);
    
    req.flash('success_msg', 'Review deleted successfully');
    res.redirect(`/cars/${review.car}`);
  } catch (error) {
    console.error('Delete review error:', error);
    req.flash('error_msg', 'Failed to delete review');
    res.redirect('/customer/dashboard');
  }
};

// Get edit review form
export const getEditReviewForm = async (req, res) => {
  try {
    const review = await Review.findById(req.params.id).populate('car', 'title image');
    
    if (!review) {
      req.flash('error_msg', 'Review not found');
      return res.redirect('/customer/dashboard');
    }
    
    // Check if user owns this review
    if (review.user.toString() !== req.user.id) {
      req.flash('error_msg', 'Not authorized to edit this review');
      return res.redirect(`/cars/${review.car._id}`);
    }
    
    res.render('reviews/edit', {
      title: 'Edit Review',
      review
    });
  } catch (error) {
    console.error('Get edit review form error:', error);
    req.flash('error_msg', 'Failed to load review edit form');
    res.redirect('/customer/dashboard');
  }
};

// Get user's reviews
export const getUserReviews = async (req, res) => {
  try {
    const reviews = await Review.find({ user: req.user.id })
      .populate('car', 'title image')
      .sort({ createdAt: -1 });
    
    res.render('customer/reviews', {
      title: 'Your Reviews',
      reviews
    });
  } catch (error) {
    console.error('Get user reviews error:', error);
    req.flash('error_msg', 'Failed to load reviews');
    res.redirect('/customer/dashboard');
  }
};

// Get car reviews
export const getCarReviews = async (req, res) => {
  try {
    const { carId } = req.params;
    
    const car = await Car.findById(carId).select('title image');
    if (!car) {
      req.flash('error_msg', 'Car not found');
      return res.redirect('/cars');
    }
    
    const reviews = await Review.find({ car: carId })
      .populate('user', 'name')
      .sort({ createdAt: -1 });
    
    res.render('cars/reviews', {
      title: `Reviews for ${car.title}`,
      car,
      reviews
    });
  } catch (error) {
    console.error('Get car reviews error:', error);
    req.flash('error_msg', 'Failed to load reviews');
    res.redirect(`/cars/${req.params.carId}`);
  }
};