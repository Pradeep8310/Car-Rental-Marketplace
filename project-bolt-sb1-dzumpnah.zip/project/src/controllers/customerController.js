import Car from '../models/Car.js';
import Booking from '../models/Booking.js';
import User from '../models/User.js';
import Review from '../models/Review.js';

// Get customer dashboard
export const getDashboard = async (req, res) => {
  try {
    // Get recent bookings
    const recentBookings = await Booking.find({ user: req.user.id })
      .populate({
        path: 'car',
        select: 'title image price'
      })
      .sort({ createdAt: -1 })
      .limit(3);
    
    // Get recent reviews
    const recentReviews = await Review.find({ user: req.user.id })
      .populate({
        path: 'car',
        select: 'title image'
      })
      .sort({ createdAt: -1 })
      .limit(3);
    
    // Get featured cars
    const featuredCars = await Car.find({ isAvailable: true })
      .populate('category')
      .sort({ price: -1 })
      .limit(4);
    
    // Get total bookings
    const totalBookings = await Booking.countDocuments({ user: req.user.id });
    
    // Get total amount spent
    const totalSpent = await Booking.aggregate([
      { 
        $match: { 
          user: req.user.id,
          status: { $in: ['confirmed', 'completed'] }
        }
      },
      {
        $group: {
          _id: null,
          total: { $sum: '$totalPrice' }
        }
      }
    ]);
    
    const totalAmount = totalSpent.length > 0 ? totalSpent[0].total : 0;
    
    res.render('customer/dashboard', {
      title: 'Customer Dashboard',
      recentBookings,
      recentReviews,
      featuredCars,
      totalBookings,
      totalAmount
    });
  } catch (error) {
    console.error('Customer dashboard error:', error);
    req.flash('error_msg', 'Failed to load dashboard');
    res.redirect('/');
  }
};

// Get customer profile
export const getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id);
    
    res.render('customer/profile', {
      title: 'My Profile',
      user
    });
  } catch (error) {
    console.error('Get customer profile error:', error);
    req.flash('error_msg', 'Failed to load profile');
    res.redirect('/customer/dashboard');
  }
};

// Update customer profile
export const updateProfile = async (req, res) => {
  try {
    const { name, phone, address } = req.body;
    
    await User.findByIdAndUpdate(req.user.id, {
      name,
      phone,
      address
    });
    
    req.flash('success_msg', 'Profile updated successfully');
    res.redirect('/customer/profile');
  } catch (error) {
    console.error('Update customer profile error:', error);
    req.flash('error_msg', 'Failed to update profile');
    res.redirect('/customer/profile');
  }
};

// Get favorite cars
export const getFavoriteCars = async (req, res) => {
  try {
    // Get cars from completed bookings
    const bookings = await Booking.find({
      user: req.user.id,
      status: 'completed'
    }).distinct('car');
    
    // Get cars that user reviewed with high ratings
    const highRatedReviews = await Review.find({
      user: req.user.id,
      rating: { $gte: 4 }
    }).distinct('car');
    
    // Combine both lists and remove duplicates
    const carIds = [...new Set([...bookings, ...highRatedReviews])];
    
    // Get car details
    const cars = await Car.find({ _id: { $in: carIds } })
      .populate('category')
      .sort({ createdAt: -1 });
    
    res.render('customer/favorites', {
      title: 'My Favorite Cars',
      cars
    });
  } catch (error) {
    console.error('Get favorite cars error:', error);
    req.flash('error_msg', 'Failed to load favorite cars');
    res.redirect('/customer/dashboard');
  }
};