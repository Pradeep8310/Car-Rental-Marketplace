import Car from '../models/Car.js';
import Category from '../models/Category.js';
import Review from '../models/Review.js';

// Get all cars
export const getAllCars = async (req, res) => {
  try {
    const { category, location, minPrice, maxPrice, transmission, fuel } = req.query;
    
    // Build query
    const query = {};
    
    if (category) query.category = category;
    if (location) query.location = { $regex: location, $options: 'i' };
    if (transmission) query.transmission = transmission;
    if (fuel) query.fuel = fuel;
    
    // Price range
    if (minPrice || maxPrice) {
      query.price = {};
      if (minPrice) query.price.$gte = minPrice;
      if (maxPrice) query.price.$lte = maxPrice;
    }
    
    // Get cars
    const cars = await Car.find(query)
      .populate('category')
      .populate('owner', 'name')
      .populate('reviews');
    
    // Get categories for filter
    const categories = await Category.find();
    
    res.render('cars/index', {
      title: 'All Cars',
      cars,
      categories,
      filters: req.query
    });
  } catch (error) {
    console.error('Get all cars error:', error);
    req.flash('error_msg', 'Failed to load cars');
    res.redirect('/');
  }
};

// Get single car
export const getCarById = async (req, res) => {
  try {
    const car = await Car.findById(req.params.id)
      .populate('category')
      .populate('owner', 'name')
      .populate({
        path: 'reviews',
        populate: {
          path: 'user',
          select: 'name'
        }
      });
    
    if (!car) {
      req.flash('error_msg', 'Car not found');
      return res.redirect('/cars');
    }
    
    res.render('cars/show', {
      title: car.title,
      car
    });
  } catch (error) {
    console.error('Get car by ID error:', error);
    req.flash('error_msg', 'Failed to load car details');
    res.redirect('/cars');
  }
};

// Get car creation form
export const getCreateCarForm = async (req, res) => {
  try {
    const categories = await Category.find();
    
    res.render('cars/create', {
      title: 'Add New Car',
      categories
    });
  } catch (error) {
    console.error('Get car form error:', error);
    req.flash('error_msg', 'Failed to load car form');
    res.redirect('/owner/dashboard');
  }
};

// Create new car
export const createCar = async (req, res) => {
  try {
    const {
      title,
      description,
      price,
      location,
      year,
      transmission,
      fuel,
      seats,
      image,
      category,
      features
    } = req.body;
    
    // Convert features string to array if needed
    const featuresArray = typeof features === 'string' 
      ? features.split(',').map(feature => feature.trim()) 
      : features || [];
    
    // Create car
    await Car.create({
      title,
      description,
      price,
      location,
      year,
      transmission,
      fuel,
      seats,
      image,
      category,
      features: featuresArray,
      owner: req.user.id
    });
    
    req.flash('success_msg', 'Car added successfully');
    res.redirect('/owner/cars');
  } catch (error) {
    console.error('Create car error:', error);
    req.flash('error_msg', 'Failed to add car');
    res.redirect('/cars/create');
  }
};

// Get car update form
export const getUpdateCarForm = async (req, res) => {
  try {
    const car = await Car.findById(req.params.id);
    
    if (!car) {
      req.flash('error_msg', 'Car not found');
      return res.redirect('/owner/cars');
    }
    
    // Check if user is owner
    if (car.owner.toString() !== req.user.id) {
      req.flash('error_msg', 'Not authorized');
      return res.redirect('/owner/cars');
    }
    
    const categories = await Category.find();
    
    res.render('cars/edit', {
      title: 'Edit Car',
      car,
      categories
    });
  } catch (error) {
    console.error('Get update car form error:', error);
    req.flash('error_msg', 'Failed to load car edit form');
    res.redirect('/owner/cars');
  }
};

// Update car
export const updateCar = async (req, res) => {
  try {
    const car = await Car.findById(req.params.id);
    
    if (!car) {
      req.flash('error_msg', 'Car not found');
      return res.redirect('/owner/cars');
    }
    
    // Check if user is owner
    if (car.owner.toString() !== req.user.id) {
      req.flash('error_msg', 'Not authorized');
      return res.redirect('/owner/cars');
    }
    
    const {
      title,
      description,
      price,
      location,
      year,
      transmission,
      fuel,
      seats,
      image,
      category,
      features,
      isAvailable
    } = req.body;
    
    // Convert features string to array if needed
    const featuresArray = typeof features === 'string' 
      ? features.split(',').map(feature => feature.trim()) 
      : features || [];
    
    // Update car
    await Car.findByIdAndUpdate(req.params.id, {
      title,
      description,
      price,
      location,
      year,
      transmission,
      fuel,
      seats,
      image,
      category,
      features: featuresArray,
      isAvailable: isAvailable === 'on' || isAvailable === true
    });
    
    req.flash('success_msg', 'Car updated successfully');
    res.redirect('/owner/cars');
  } catch (error) {
    console.error('Update car error:', error);
    req.flash('error_msg', 'Failed to update car');
    res.redirect(`/cars/${req.params.id}/edit`);
  }
};

// Delete car
export const deleteCar = async (req, res) => {
  try {
    const car = await Car.findById(req.params.id);
    
    if (!car) {
      req.flash('error_msg', 'Car not found');
      return res.redirect('/owner/cars');
    }
    
    // Check if user is owner
    if (car.owner.toString() !== req.user.id) {
      req.flash('error_msg', 'Not authorized');
      return res.redirect('/owner/cars');
    }
    
    // Delete car
    await Car.findByIdAndDelete(req.params.id);
    
    // Delete all reviews for this car
    await Review.deleteMany({ car: req.params.id });
    
    req.flash('success_msg', 'Car deleted successfully');
    res.redirect('/owner/cars');
  } catch (error) {
    console.error('Delete car error:', error);
    req.flash('error_msg', 'Failed to delete car');
    res.redirect('/owner/cars');
  }
};