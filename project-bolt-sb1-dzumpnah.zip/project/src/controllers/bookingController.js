import Booking from '../models/Booking.js';
import Car from '../models/Car.js';

// Get customer bookings
export const getCustomerBookings = async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.user.id })
      .populate({
        path: 'car',
        select: 'title image price'
      })
      .sort({ createdAt: -1 });
    
    res.render('customer/bookings', {
      title: 'Your Bookings',
      bookings
    });
  } catch (error) {
    console.error('Get customer bookings error:', error);
    req.flash('error_msg', 'Failed to load bookings');
    res.redirect('/customer/dashboard');
  }
};

// Get owner bookings
export const getOwnerBookings = async (req, res) => {
  try {
    // Get all cars owned by this owner
    const cars = await Car.find({ owner: req.user.id }).select('_id');
    const carIds = cars.map(car => car._id);
    
    // Get all bookings for these cars
    const bookings = await Booking.find({ car: { $in: carIds } })
      .populate({
        path: 'car',
        select: 'title image price'
      })
      .populate('user', 'name email')
      .sort({ createdAt: -1 });
    
    res.render('owner/bookings', {
      title: 'Bookings for Your Cars',
      bookings
    });
  } catch (error) {
    console.error('Get owner bookings error:', error);
    req.flash('error_msg', 'Failed to load bookings');
    res.redirect('/owner/dashboard');
  }
};

// Get booking details
export const getBookingDetails = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id)
      .populate({
        path: 'car',
        select: 'title description image price location year transmission fuel seats features'
      })
      .populate('user', 'name email phone');
    
    if (!booking) {
      req.flash('error_msg', 'Booking not found');
      return res.redirect('/customer/bookings');
    }
    
    // Check if user is allowed to view this booking
    const isOwner = req.user.role === 'owner' && 
      booking.car.owner && 
      booking.car.owner.toString() === req.user.id;
    
    const isCustomer = booking.user._id.toString() === req.user.id;
    
    if (!isOwner && !isCustomer) {
      req.flash('error_msg', 'Not authorized to view this booking');
      return res.redirect('/');
    }
    
    res.render('bookings/show', {
      title: 'Booking Details',
      booking,
      isOwner
    });
  } catch (error) {
    console.error('Get booking details error:', error);
    req.flash('error_msg', 'Failed to load booking details');
    res.redirect('/customer/bookings');
  }
};

// Update booking status
export const updateBookingStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    const booking = await Booking.findById(id).populate('car');
    
    if (!booking) {
      req.flash('error_msg', 'Booking not found');
      return res.redirect('/owner/bookings');
    }
    
    // Verify owner
    const cars = await Car.find({ owner: req.user.id }).select('_id');
    const carIds = cars.map(car => car._id.toString());
    
    if (!carIds.includes(booking.car._id.toString())) {
      req.flash('error_msg', 'Not authorized to update this booking');
      return res.redirect('/owner/bookings');
    }
    
    // Update status
    booking.status = status;
    await booking.save();
    
    req.flash('success_msg', 'Booking status updated');
    res.redirect(`/bookings/${id}`);
  } catch (error) {
    console.error('Update booking status error:', error);
    req.flash('error_msg', 'Failed to update booking status');
    res.redirect('/owner/bookings');
  }
};

// Cancel booking
export const cancelBooking = async (req, res) => {
  try {
    const booking = await Booking.findById(req.params.id);
    
    if (!booking) {
      req.flash('error_msg', 'Booking not found');
      return res.redirect('/customer/bookings');
    }
    
    // Check if user owns this booking
    if (booking.user.toString() !== req.user.id) {
      req.flash('error_msg', 'Not authorized to cancel this booking');
      return res.redirect('/customer/bookings');
    }
    
    // Can only cancel if status is pending or confirmed
    if (!['pending', 'confirmed'].includes(booking.status)) {
      req.flash('error_msg', 'Cannot cancel booking with current status');
      return res.redirect(`/bookings/${req.params.id}`);
    }
    
    // Update status
    booking.status = 'cancelled';
    await booking.save();
    
    req.flash('success_msg', 'Booking cancelled successfully');
    res.redirect('/customer/bookings');
  } catch (error) {
    console.error('Cancel booking error:', error);
    req.flash('error_msg', 'Failed to cancel booking');
    res.redirect('/customer/bookings');
  }
};