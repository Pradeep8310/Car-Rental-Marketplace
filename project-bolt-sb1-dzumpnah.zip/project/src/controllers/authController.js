import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import Cart from '../models/Cart.js';

// Register user
export const register = async (req, res) => {
  try {
    const { name, email, password, role } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      req.flash('error_msg', 'Email already registered');
      return res.redirect('/auth/register');
    }

    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Create user
    const user = await User.create({
      name,
      email,
      password: hashedPassword,
      role: role || 'customer'
    });

    // Create empty cart for user
    await Cart.create({ user: user._id, items: [] });

    // Create token
    const token = jwt.sign({ id: user._id }, 'your-jwt-secret', { expiresIn: '30d' });
    
    // Set cookie
    res.cookie('token', token, {
      httpOnly: true,
      maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    });

    req.flash('success_msg', 'You are now registered and can log in');
    res.redirect('/auth/login');
  } catch (error) {
    console.error('Register error:', error);
    req.flash('error_msg', 'An error occurred during registration');
    res.redirect('/auth/register');
  }
};

// Login user
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // Check if user exists
    const user = await User.findOne({ email });
    if (!user) {
      req.flash('error_msg', 'Invalid email or password');
      return res.redirect('/auth/login');
    }

    // Validate password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      req.flash('error_msg', 'Invalid email or password');
      return res.redirect('/auth/login');
    }

    // Create token
    const token = jwt.sign({ id: user._id }, 'your-jwt-secret', { expiresIn: '30d' });
    
    // Set cookie
    res.cookie('token', token, {
      httpOnly: true,
      maxAge: 30 * 24 * 60 * 60 * 1000 // 30 days
    });

    if (user.role === 'owner') {
      res.redirect('/owner/dashboard');
    } else {
      res.redirect('/customer/dashboard');
    }
  } catch (error) {
    console.error('Login error:', error);
    req.flash('error_msg', 'An error occurred during login');
    res.redirect('/auth/login');
  }
};

// Logout user
export const logout = (req, res) => {
  res.clearCookie('token');
  req.flash('success_msg', 'You are logged out');
  res.redirect('/');
};

// Get login page
export const getLoginPage = (req, res) => {
  res.render('auth/login', { title: 'Login' });
};

// Get register page
export const getRegisterPage = (req, res) => {
  res.render('auth/register', { title: 'Register' });
};