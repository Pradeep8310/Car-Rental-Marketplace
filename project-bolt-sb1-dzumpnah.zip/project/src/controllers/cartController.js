import Cart from '../models/Cart.js';
import Car from '../models/Car.js';
import Booking from '../models/Booking.js';

// Get cart
export const getCart = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user.id }).populate({
      path: 'items.car',
      select: 'title image price'
    });
    
    res.render('cart/index', {
      title: 'Your Cart',
      cart: cart || { items: [], totalAmount: 0 }
    });
  } catch (error) {
    console.error('Get cart error:', error);
    req.flash('error_msg', 'Failed to load cart');
    res.redirect('/');
  }
};

// Add to cart
export const addToCart = async (req, res) => {
  try {
    const { carId, startDate, endDate } = req.body;
    
    // Validate dates
    const start = new Date(startDate);
    const end = new Date(endDate);
    
    if (start >= end) {
      req.flash('error_msg', 'End date must be after start date');
      return res.redirect(`/cars/${carId}`);
    }
    
    // Calculate days
    const diffTime = Math.abs(end - start);
    const days = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1;
    
    // Get car
    const car = await Car.findById(carId);
    if (!car) {
      req.flash('error_msg', 'Car not found');
      return res.redirect('/cars');
    }
    
    // Check if car is available
    if (!car.isAvailable) {
      req.flash('error_msg', 'Car is not available for booking');
      return res.redirect(`/cars/${carId}`);
    }
    
    // Get or create cart
    let cart = await Cart.findOne({ user: req.user.id });
    if (!cart) {
      cart = new Cart({ user: req.user.id, items: [] });
    }
    
    // Check if car already in cart
    const existingItem = cart.items.find(item => 
      item.car.toString() === carId
    );
    
    if (existingItem) {
      // Update existing item
      existingItem.startDate = start;
      existingItem.endDate = end;
      existingItem.days = days;
      existingItem.totalPrice = days * car.price;
    } else {
      // Add new item
      cart.items.push({
        car: carId,
        startDate: start,
        endDate: end,
        days,
        price: car.price,
        totalPrice: days * car.price
      });
    }
    
    await cart.save();
    
    req.flash('success_msg', 'Added to cart');
    res.redirect('/cart');
  } catch (error) {
    console.error('Add to cart error:', error);
    req.flash('error_msg', 'Failed to add to cart');
    res.redirect(`/cars/${req.body.carId}`);
  }
};

// Remove from cart
export const removeFromCart = async (req, res) => {
  try {
    const { itemId } = req.params;
    
    const cart = await Cart.findOne({ user: req.user.id });
    if (!cart) {
      req.flash('error_msg', 'Cart not found');
      return res.redirect('/cart');
    }
    
    // Remove item
    cart.items = cart.items.filter(item => item._id.toString() !== itemId);
    
    await cart.save();
    
    req.flash('success_msg', 'Item removed from cart');
    res.redirect('/cart');
  } catch (error) {
    console.error('Remove from cart error:', error);
    req.flash('error_msg', 'Failed to remove item from cart');
    res.redirect('/cart');
  }
};

// Checkout
export const checkout = async (req, res) => {
  try {
    const cart = await Cart.findOne({ user: req.user.id }).populate('items.car');
    
    if (!cart || cart.items.length === 0) {
      req.flash('error_msg', 'Your cart is empty');
      return res.redirect('/cart');
    }
    
    // Create bookings for each item
    const bookings = [];
    
    for (const item of cart.items) {
      const booking = await Booking.create({
        car: item.car._id,
        user: req.user.id,
        startDate: item.startDate,
        endDate: item.endDate,
        totalPrice: item.totalPrice,
        status: 'confirmed',
        paymentStatus: 'paid'
      });
      
      bookings.push(booking);
    }
    
    // Clear cart
    cart.items = [];
    await cart.save();
    
    req.flash('success_msg', 'Booking successful');
    res.redirect('/customer/bookings');
  } catch (error) {
    console.error('Checkout error:', error);
    req.flash('error_msg', 'Failed to complete checkout');
    res.redirect('/cart');
  }
};