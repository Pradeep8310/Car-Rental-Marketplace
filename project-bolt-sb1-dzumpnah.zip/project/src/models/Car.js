import mongoose from 'mongoose';

const carSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Please provide a title'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Please provide a description']
  },
  price: {
    type: Number,
    required: [true, 'Please provide a price per day']
  },
  location: {
    type: String,
    required: [true, 'Please provide a location']
  },
  year: {
    type: Number,
    required: [true, 'Please provide the car year']
  },
  transmission: {
    type: String,
    enum: ['Manual', 'Automatic'],
    default: 'Automatic'
  },
  fuel: {
    type: String,
    enum: ['Gasoline', 'Diesel', 'Electric', 'Hybrid'],
    default: 'Gasoline'
  },
  seats: {
    type: Number,
    required: [true, 'Please provide the number of seats']
  },
  image: {
    type: String,
    default: 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg'
  },
  features: {
    type: [String]
  },
  category: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Category',
    required: true
  },
  owner: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  isAvailable: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
}, { timestamps: true, toJSON: { virtuals: true }, toObject: { virtuals: true } });

// Virtual for reviews
carSchema.virtual('reviews', {
  ref: 'Review',
  localField: '_id',
  foreignField: 'car',
  justOne: false
});

// Method to get average rating
carSchema.virtual('averageRating').get(function() {
  if (this.reviews && this.reviews.length > 0) {
    const sum = this.reviews.reduce((total, review) => total + review.rating, 0);
    return (sum / this.reviews.length).toFixed(1);
  }
  return 0;
});

const Car = mongoose.model('Car', carSchema);

export default Car;