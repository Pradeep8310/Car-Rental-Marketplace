// Main JavaScript file

// Wait for DOM to be loaded
document.addEventListener('DOMContentLoaded', function() {
  // Initialize navbar scroll behavior
  initNavbar();
  
  // Initialize date pickers
  initDatePickers();
  
  // Initialize tooltips
  initTooltips();
  
  // Initialize flash message dismissal
  initFlashMessages();
  
  // Initialize image previews
  initImagePreviews();
  
  // Calculate booking total in real-time
  initBookingCalculator();
  
  // Initialize modals
  initModals();
});

// Navbar scroll behavior
function initNavbar() {
  const navbar = document.querySelector('.navbar-fixed');
  if (!navbar) return;
  
  window.addEventListener('scroll', function() {
    if (window.scrollY > 50) {
      navbar.classList.remove('navbar-transparent');
      navbar.classList.add('navbar-solid');
    } else {
      navbar.classList.add('navbar-transparent');
      navbar.classList.remove('navbar-solid');
    }
  });
  
  // Initial check
  if (window.scrollY > 50) {
    navbar.classList.remove('navbar-transparent');
    navbar.classList.add('navbar-solid');
  }
}

// Initialize date pickers
function initDatePickers() {
  const startDateInputs = document.querySelectorAll('input[name="startDate"]');
  const endDateInputs = document.querySelectorAll('input[name="endDate"]');
  
  if (startDateInputs.length && endDateInputs.length) {
    startDateInputs.forEach((startInput, index) => {
      const endInput = endDateInputs[index];
      
      // Set min date for start date to today
      const today = new Date().toISOString().split('T')[0];
      startInput.min = today;
      
      // When start date changes, update end date min value
      startInput.addEventListener('change', function() {
        endInput.min = startInput.value;
        
        // If end date is before start date, reset it
        if (endInput.value && endInput.value < startInput.value) {
          endInput.value = startInput.value;
        }
        
        // Update total if calculator exists
        updateBookingTotal();
      });
      
      // Update total when end date changes
      endInput.addEventListener('change', updateBookingTotal);
    });
  }
}

// Initialize tooltips
function initTooltips() {
  const tooltips = document.querySelectorAll('[data-tooltip]');
  
  tooltips.forEach(tooltip => {
    tooltip.addEventListener('mouseenter', function() {
      const text = this.getAttribute('data-tooltip');
      
      // Create tooltip element
      const tooltipEl = document.createElement('div');
      tooltipEl.classList.add('tooltip');
      tooltipEl.textContent = text;
      tooltipEl.style.position = 'absolute';
      tooltipEl.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
      tooltipEl.style.color = 'white';
      tooltipEl.style.padding = '5px 10px';
      tooltipEl.style.borderRadius = '5px';
      tooltipEl.style.fontSize = '14px';
      tooltipEl.style.zIndex = '100';
      
      // Position tooltip
      const rect = this.getBoundingClientRect();
      tooltipEl.style.top = `${rect.bottom + window.scrollY + 5}px`;
      tooltipEl.style.left = `${rect.left + window.scrollX}px`;
      
      // Add to DOM
      document.body.appendChild(tooltipEl);
      
      // Store reference to tooltip
      this.tooltipElement = tooltipEl;
    });
    
    tooltip.addEventListener('mouseleave', function() {
      if (this.tooltipElement) {
        document.body.removeChild(this.tooltipElement);
        this.tooltipElement = null;
      }
    });
  });
}

// Initialize flash message dismissal
function initFlashMessages() {
  const flashMessages = document.querySelectorAll('.flash-message');
  
  flashMessages.forEach(message => {
    const closeBtn = message.querySelector('.close-btn');
    
    if (closeBtn) {
      closeBtn.addEventListener('click', function() {
        message.style.opacity = '0';
        
        setTimeout(() => {
          message.style.display = 'none';
        }, 300);
      });
    }
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
      message.style.opacity = '0';
      
      setTimeout(() => {
        message.style.display = 'none';
      }, 300);
    }, 5000);
  });
}

// Initialize image previews
function initImagePreviews() {
  const imageInput = document.getElementById('image');
  const imagePreview = document.getElementById('image-preview');
  
  if (imageInput && imagePreview) {
    imageInput.addEventListener('change', function() {
      const file = this.files[0];
      
      if (file) {
        const reader = new FileReader();
        
        reader.addEventListener('load', function() {
          imagePreview.src = reader.result;
          imagePreview.style.display = 'block';
        });
        
        reader.readAsDataURL(file);
      }
    });
  }
}

// Initialize booking calculator
function initBookingCalculator() {
  // Add event listeners to update total when dates change
  const pricePerDay = document.getElementById('price-per-day');
  if (!pricePerDay) return;
  
  // Initialize total with current dates
  updateBookingTotal();
}

// Calculate and update booking total
function updateBookingTotal() {
  const pricePerDay = document.getElementById('price-per-day');
  const totalElement = document.getElementById('total-price');
  const startDateInput = document.querySelector('input[name="startDate"]');
  const endDateInput = document.querySelector('input[name="endDate"]');
  
  if (!pricePerDay || !totalElement || !startDateInput || !endDateInput) return;
  
  const startDate = new Date(startDateInput.value);
  const endDate = new Date(endDateInput.value);
  
  if (startDate && endDate && startDate <= endDate) {
    // Calculate number of days
    const diffTime = Math.abs(endDate - startDate);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) || 1; // Minimum 1 day
    
    // Get daily price
    const price = parseFloat(pricePerDay.dataset.price);
    
    // Calculate total
    const total = diffDays * price;
    
    // Update total display
    totalElement.textContent = `$${total.toFixed(2)}`;
    
    // Update hidden input if it exists
    const totalInput = document.querySelector('input[name="totalPrice"]');
    if (totalInput) {
      totalInput.value = total.toFixed(2);
    }
    
    // Update days display
    const daysElement = document.getElementById('rental-days');
    if (daysElement) {
      daysElement.textContent = diffDays;
    }
    
    // Update hidden days input if it exists
    const daysInput = document.querySelector('input[name="days"]');
    if (daysInput) {
      daysInput.value = diffDays;
    }
  }
}

// Initialize modals
function initModals() {
  const modalButtons = document.querySelectorAll('[data-modal-target]');
  const closeButtons = document.querySelectorAll('[data-modal-close]');
  const modals = document.querySelectorAll('.modal');
  
  // Open modal
  modalButtons.forEach(button => {
    button.addEventListener('click', function() {
      const modalId = this.getAttribute('data-modal-target');
      const modal = document.getElementById(modalId);
      
      if (modal) {
        modal.classList.remove('hidden');
        document.body.classList.add('overflow-hidden');
      }
    });
  });
  
  // Close modal
  closeButtons.forEach(button => {
    button.addEventListener('click', function() {
      const modal = this.closest('.modal');
      
      if (modal) {
        modal.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
      }
    });
  });
  
  // Close modal when clicking outside
  modals.forEach(modal => {
    modal.addEventListener('click', function(e) {
      if (e.target === this) {
        this.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
      }
    });
  });
}