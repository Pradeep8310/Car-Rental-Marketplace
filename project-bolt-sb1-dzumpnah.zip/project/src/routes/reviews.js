import express from 'express';
import { isLoggedIn, isCustomer } from '../middleware/authMiddleware.js';
import {
  createReview,
  deleteReview,
  getEditReviewForm,
  getUserReviews,
  getCarReviews
} from '../controllers/reviewController.js';

const router = express.Router();

// Create review
router.post('/', isLoggedIn, isCustomer, createReview);

// Delete review
router.delete('/:id', isLoggedIn, isCustomer, deleteReview);

// Get edit review form
router.get('/:id/edit', isLoggedIn, isCustomer, getEditReviewForm);

// Get user's reviews
router.get('/user', isLoggedIn, isCustomer, getUserReviews);

// Get car reviews
router.get('/car/:carId', getCarReviews);

export default router;