import express from 'express';
import {
  register,
  login,
  logout,
  getLoginPage,
  getRegisterPage
} from '../controllers/authController.js';

const router = express.Router();

// Register user
router.post('/register', register);

// Login user
router.post('/login', login);

// Logout user
router.get('/logout', logout);

// Get login page
router.get('/login', getLoginPage);

// Get register page
router.get('/register', getRegisterPage);

export default router;