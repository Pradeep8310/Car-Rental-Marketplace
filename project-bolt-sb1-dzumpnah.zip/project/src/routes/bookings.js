import express from 'express';
import { isLoggedIn, isOwner, isCustomer } from '../middleware/authMiddleware.js';
import {
  getBookingDetails,
  updateBookingStatus,
  cancelBooking
} from '../controllers/bookingController.js';

const router = express.Router();

// Get booking details
router.get('/:id', isLoggedIn, getBookingDetails);

// Update booking status (owner only)
router.put('/:id/status', isLoggedIn, isOwner, updateBookingStatus);

// Cancel booking (customer only)
router.put('/:id/cancel', isLoggedIn, isCustomer, cancelBooking);

export default router;