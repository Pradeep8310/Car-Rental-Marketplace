import express from 'express';
import {
  getHomePage,
  getAboutPage,
  getContactPage,
  getErrorPage
} from '../controllers/indexController.js';

const router = express.Router();

// Home page
router.get('/', getHomePage);

// About page
router.get('/about', getAboutPage);

// Contact page
router.get('/contact', getContactPage);

// Error page
router.get('/404', getErrorPage);

export default router;