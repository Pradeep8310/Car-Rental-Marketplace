import express from 'express';
import { isLoggedIn, isOwner } from '../middleware/authMiddleware.js';
import {
  getDashboard,
  getCars,
  getProfile,
  updateProfile,
  getEarningsReport
} from '../controllers/ownerController.js';
import { getOwnerBookings } from '../controllers/bookingController.js';

const router = express.Router();

// Owner dashboard
router.get('/dashboard', isLoggedIn, isOwner, getDashboard);

// Owner cars
router.get('/cars', isLoggedIn, isOwner, getCars);

// Owner bookings
router.get('/bookings', isLoggedIn, isOwner, getOwnerBookings);

// Owner profile
router.get('/profile', isLoggedIn, isOwner, getProfile);

// Update owner profile
router.put('/profile', isLoggedIn, isOwner, updateProfile);

// Earnings report
router.get('/earnings', isLoggedIn, isOwner, getEarningsReport);

export default router;