import express from 'express';
import { isLoggedIn, isOwner } from '../middleware/authMiddleware.js';
import {
  getAllCars,
  getCarById,
  getCreateCarForm,
  createCar,
  getUpdateCarForm,
  updateCar,
  deleteCar
} from '../controllers/carController.js';

const router = express.Router();

// Get all cars
router.get('/', getAllCars);

// Get single car
router.get('/:id', getCarById);

// Get car creation form
router.get('/create', isLoggedIn, isOwner, getCreateCarForm);

// Create new car
router.post('/', isLoggedIn, isOwner, createCar);

// Get car update form
router.get('/:id/edit', isLoggedIn, isOwner, getUpdateCarForm);

// Update car
router.put('/:id', isLoggedIn, isOwner, updateCar);

// Delete car
router.delete('/:id', isLoggedIn, isOwner, deleteCar);

export default router;