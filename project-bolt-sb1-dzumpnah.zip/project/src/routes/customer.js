import express from 'express';
import { isLoggedIn, isCustomer } from '../middleware/authMiddleware.js';
import {
  getDashboard,
  getProfile,
  updateProfile,
  getFavoriteCars
} from '../controllers/customerController.js';
import { getCustomerBookings } from '../controllers/bookingController.js';
import { getUserReviews } from '../controllers/reviewController.js';

const router = express.Router();

// Customer dashboard
router.get('/dashboard', isLoggedIn, isCustomer, getDashboard);

// Customer bookings
router.get('/bookings', isLoggedIn, isCustomer, getCustomerBookings);

// Customer reviews
router.get('/reviews', isLoggedIn, isCustomer, getUserReviews);

// Customer profile
router.get('/profile', isLoggedIn, isCustomer, getProfile);

// Update customer profile
router.put('/profile', isLoggedIn, isCustomer, updateProfile);

// Favorite cars
router.get('/favorites', isLoggedIn, isCustomer, getFavoriteCars);

export default router;