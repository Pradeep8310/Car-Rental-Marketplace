import express from 'express';
import { isLoggedIn, isCustomer } from '../middleware/authMiddleware.js';
import {
  getCart,
  addToCart,
  removeFromCart,
  checkout
} from '../controllers/cartController.js';

const router = express.Router();

// Get cart
router.get('/', isLoggedIn, isCustomer, getCart);

// Add to cart
router.post('/', isLoggedIn, isCustomer, addToCart);

// Remove from cart
router.delete('/:itemId', isLoggedIn, isCustomer, removeFromCart);

// Checkout
router.post('/checkout', isLoggedIn, isCustomer, checkout);

export default router;