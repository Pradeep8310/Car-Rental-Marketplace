import mongoose from 'mongoose';

export const connectDB = async () => {
  try {
    const conn = await mongoose.connect('mongodb://localhost:27017/car-rental-marketplace', {
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 90000,
      connectTimeoutMS: 60000,
      retryWrites: true,
      maxPoolSize: 10
    });
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`Error connecting to MongoDB: ${error.message}`);
    process.exit(1);
  }
};