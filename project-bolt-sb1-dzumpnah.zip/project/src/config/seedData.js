import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { connectDB } from './db.js';
import User from '../models/User.js';
import Car from '../models/Car.js';
import Category from '../models/Category.js';

// Connect to database
connectDB();

// Sample categories
const categories = [
  { name: 'SUV', description: 'Sport Utility Vehicles with higher ground clearance' },
  { name: 'Sedan', description: 'Traditional four-door cars with trunk space' },
  { name: 'Luxury', description: 'Premium vehicles with advanced features' },
  { name: 'Economy', description: 'Affordable, fuel-efficient vehicles' },
  { name: 'Sports', description: 'High-performance vehicles designed for speed' },
  { name: 'Electric', description: 'Fully electric, environmentally friendly vehicles' }
];

// Sample cars
const cars = [
  {
    title: 'Tesla Model S',
    description: 'Luxury electric sedan with autopilot features and long range.',
    price: 150,
    location: 'San Francisco',
    year: 2023,
    transmission: 'Automatic',
    fuel: 'Electric',
    seats: 5,
    image: 'https://images.pexels.com/photos/12861709/pexels-photo-12861709.jpeg',
    category: 'Electric',
    features: ['Autopilot', 'Premium Sound', 'Supercharging', 'Long Range']
  },
  {
    title: 'Toyota Camry',
    description: 'Reliable and comfortable sedan for everyday driving.',
    price: 75,
    location: 'Los Angeles',
    year: 2022,
    transmission: 'Automatic',
    fuel: 'Gasoline',
    seats: 5,
    image: 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg',
    category: 'Sedan',
    features: ['Bluetooth', 'Backup Camera', 'Cruise Control', 'USB Ports']
  },
  {
    title: 'Ford Explorer',
    description: 'Spacious SUV perfect for family trips and outdoor adventures.',
    price: 120,
    location: 'Chicago',
    year: 2023,
    transmission: 'Automatic',
    fuel: 'Gasoline',
    seats: 7,
    image: 'https://images.pexels.com/photos/116675/pexels-photo-116675.jpeg',
    category: 'SUV',
    features: ['3rd Row Seating', 'AWD', 'Navigation', 'Roof Rack']
  },
  {
    title: 'BMW 5 Series',
    description: 'Elegant luxury sedan with premium features and powerful performance.',
    price: 180,
    location: 'New York',
    year: 2023,
    transmission: 'Automatic',
    fuel: 'Gasoline',
    seats: 5,
    image: 'https://images.pexels.com/photos/892522/pexels-photo-892522.jpeg',
    category: 'Luxury',
    features: ['Leather Seats', 'Premium Sound', 'Heated Seats', 'Advanced Safety']
  },
  {
    title: 'Chevrolet Spark',
    description: 'Compact and affordable city car with excellent fuel efficiency.',
    price: 45,
    location: 'Miami',
    year: 2022,
    transmission: 'Automatic',
    fuel: 'Gasoline',
    seats: 4,
    image: 'https://images.pexels.com/photos/1149831/pexels-photo-1149831.jpeg',
    category: 'Economy',
    features: ['Bluetooth', 'Compact Size', 'Fuel Efficient', 'Low Cost']
  },
  {
    title: 'Porsche 911',
    description: 'Iconic sports car with exhilarating performance and handling.',
    price: 250,
    location: 'Las Vegas',
    year: 2023,
    transmission: 'Automatic',
    fuel: 'Gasoline',
    seats: 2,
    image: 'https://images.pexels.com/photos/3802510/pexels-photo-3802510.jpeg',
    category: 'Sports',
    features: ['High Performance', 'Premium Sound', 'Sport Mode', 'Turbo Engine']
  }
];

// Sample users
const users = [
  {
    name: 'Owner User',
    email: 'owner@example.com',
    password: 'password123',
    role: 'owner'
  },
  {
    name: 'Customer User',
    email: 'customer@example.com',
    password: 'password123',
    role: 'customer'
  }
];

// Seed data
const seedData = async () => {
  try {
    // Clear existing data
    await User.deleteMany({});
    await Car.deleteMany({});
    await Category.deleteMany({});

    // Insert categories
    const createdCategories = await Category.insertMany(categories);
    console.log(`${createdCategories.length} categories created`);

    // Insert users with hashed passwords
    const createdUsers = await Promise.all(
      users.map(async (user) => {
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(user.password, salt);
        return User.create({
          ...user,
          password: hashedPassword
        });
      })
    );
    console.log(`${createdUsers.length} users created`);

    // Get owner user
    const owner = createdUsers.find(user => user.role === 'owner');

    // Insert cars with owner and category references
    const createdCars = await Promise.all(
      cars.map(async (car) => {
        const category = createdCategories.find(cat => cat.name === car.category);
        return Car.create({
          ...car,
          owner: owner._id,
          category: category._id
        });
      })
    );
    console.log(`${createdCars.length} cars created`);

    console.log('Database seeded successfully');
    process.exit();
  } catch (error) {
    console.error(`Error seeding data: ${error.message}`);
    process.exit(1);
  }
};

seedData();